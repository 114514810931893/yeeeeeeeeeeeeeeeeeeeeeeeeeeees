// JavasciptはほぼAI + 人間による機能拡張
document.addEventListener('DOMContentLoaded', function() {
    // HTMLから必要な要素を取得
    const searchForm = document.getElementById('search-form');
    const searchQuery = document.getElementById('search-query');
    const searchResults = document.getElementById('search-results');
    const controlsContainer = document.getElementById('controls-container');
    
    // 検索対象リストのパス
    const fileListPath = 'text/filelist.txt';
    let toggleAllButton = null;

    // 検索フォームが存在する場合のみ、イベントリスナーを登録
    if (searchForm) {
        searchForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            // ★★★ エラー対策: 必要なHTML要素が存在するかをここで確認 ★★★
            if (!searchResults || !controlsContainer) {
                console.error('エラー: HTML内に id="search-results" または id="controls-container" の要素が見つかりません。index.html ファイルを最新版に更新してください。');
                searchResults.innerHTML = '<p style="color: red;"><strong>内部エラー:</strong> ページ構成が古いため検索を実行できません。管理者に連絡してください。</p>';
                return; // 処理を中断
            }

            const query = searchQuery.value.trim();
            if (!query) return;

            // 検索開始前の表示リセット
            searchResults.innerHTML = '<p>検索中...</p>';
            controlsContainer.innerHTML = '';

            try {
                // filelist.txtを読み込み、検索対象ファイルリストを作成
                const response = await fetch(fileListPath);
                if (!response.ok) throw new Error('filelist.txt が見つかりません。');
                
                const listText = await response.text();
                const fileList = listText.split('\n').map(file => file.trim()).filter(file => file.length > 0);

                if (fileList.length === 0) {
                    searchResults.innerHTML = '<p>検索対象ファイルがありません。</p>';
                    return;
                }

                // 各ファイルを非同期で取得
                const fetchPromises = fileList.map(file => 
                    fetch(`text/${file}`)
                        .then(response => {
                            if (!response.ok) return { fileName: file, content: `エラー: ${file} が見つかりません。`, error: true };
                            return response.text().then(text => ({ fileName: file, content: text, error: false }));
                        })
                );
                
                const files = await Promise.all(fetchPromises);
                
                let hitCount = 0;
                let resultsHtml = '';

                // --- AND/OR検索ロジック ---
                const { andTerms, orTerms } = parseQuery(query);

                files.forEach(file => {
                    if (file.error) return;
                    
                    const fileNameLower = file.fileName.toLowerCase();
                    const contentLower = file.content.toLowerCase();
                    const searchTarget = fileNameLower + ' ' + contentLower;

                    // AND条件のチェック (すべてのandTermsが含まれているか)
                    const andMatch = andTerms.every(term => searchTarget.includes(term));
                    
                    // OR条件のチェック (orTermsのいずれかが含まれているか)
                    // orTermsが空の場合は、常にtrueとする
                    const orMatch = orTerms.length === 0 ? true : orTerms.some(term => searchTarget.includes(term));

                    if (andMatch && orMatch) {
                        hitCount++;
                        resultsHtml += `
                            <div class="result-item">
                                <h3>${escapeHtml(file.fileName)}</h3>
                                <pre>${highlightTerms(escapeHtml(file.content), andTerms.concat(orTerms))}</pre>
                            </div>
                        `;
                    }
                });
                // --- 検索ロジックここまで ---

                // 結果を表示
                if (hitCount > 0) {
                    searchResults.innerHTML = resultsHtml;
                    controlsContainer.innerHTML = '<button id="toggle-all-button">[ すべて開く ]</button>';
                    toggleAllButton = document.getElementById('toggle-all-button');
                    toggleAllButton.style.visibility = 'visible';
                    addToggleAllEventListener();
                } else {
                    searchResults.innerHTML = '<p>検索結果が見つかりませんでした。</p>';
                }

            } catch (error) {
                console.error('検索エラー:', error);
                searchResults.innerHTML = `<p>エラー: ${escapeHtml(error.message)}</p>`;
            }
        });
    }

    /**
     * 検索クエリを解析してAND条件とOR条件の単語に分割する関数
     * @param {string} query - 入力された検索クエリ
     * @returns {{andTerms: string[], orTerms: string[]}}
     */
    function parseQuery(query) {
        const lowerQuery = query.toLowerCase();
        // AND検索: スペースで区切られた単語 (例: "氷室 零課")
        // OR検索: "OR" で区切られた単語 (例: "梓 OR 凪")
        // 組み合わせ: "氷室 OR 梓 零課" -> AND: ["零課"], OR: ["氷室", "梓"]
        const parts = lowerQuery.split(/\s+/);
        const andTerms = [];
        const orTerms = [];
        
        let currentOrSet = [];

        parts.forEach((part, index) => {
            if (part === 'or') {
                if(index > 0 && parts[index - 1] !== 'or') {
                    // "OR"の前の単語をORタームに追加
                    if(currentOrSet.length === 0 && andTerms.length > 0) {
                       currentOrSet.push(andTerms.pop());
                    }
                }
            } else {
                if (index > 0 && parts[index - 1] === 'or') {
                    // "OR"の後の単語をORタームに追加
                    currentOrSet.push(part);
                } else if (index < parts.length - 1 && parts[index + 1] === 'or') {
                    // "OR"の前の単語をORタームに追加
                    currentOrSet.push(part);
                } else {
                    // 上記以外はANDターム
                    andTerms.push(part);
                }
            }
        });
        
        // currentOrSetをorTermsにマージ
        if(currentOrSet.length > 0) {
            orTerms.push(...currentOrSet);
        }

        // 重複を除去
        return {
            andTerms: [...new Set(andTerms)],
            orTerms: [...new Set(orTerms)]
        };
    }

    /**
     * テキスト内の検索語をハイライトする関数
     * @param {string} text - ハイライト対象のテキスト
     * @param {string[]} terms - ハイライトする単語の配列
     * @returns {string} ハイライトされたHTML文字列
     */
    function highlightTerms(text, terms) {
        if (terms.length === 0) return text;
        // 正規表現を作成（特殊文字をエスケープ）
        const regex = new RegExp(terms.map(term => term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')).join('|'), 'gi');
        return text.replace(regex, match => `<span style="background-color: #ffff00;">${match}</span>`);
    }

    // 個々の検索結果をクリックした際の開閉処理
    searchResults.addEventListener('click', function(e) {
        const header = e.target.closest('.result-item h3');
        if (header) {
            header.parentElement.classList.toggle('expanded');
        }
    });

    // 「すべて開く/閉じる」ボタンの処理
    function addToggleAllEventListener() {
        if (toggleAllButton) {
            toggleAllButton.addEventListener('click', function() {
                const allResults = document.querySelectorAll('.result-item');
                const isExpand = this.textContent.includes('開く');

                allResults.forEach(item => {
                    if (isExpand) {
                        item.classList.add('expanded');
                    } else {
                        item.classList.remove('expanded');
                    }
                });
                this.textContent = isExpand ? '[ すべて閉じる ]' : '[ すべて開く ]';
            });
        }
    }

    // HTML特殊文字をエスケープする関数
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
});

